const http = require('http');

http.get('http://localhost:3000/api/catalogos/categorias?dominioId=1', (res) => {
  let data = '';
  res.on('data', (chunk) => {
    data += chunk;
  });
  res.on('end', () => {
    console.log('Status Code:', res.statusCode);
    console.log('Response payload:', JSON.stringify(JSON.parse(data), null, 2));
  });
}).on('error', (err) => {
  console.error('Error fetching categories:', err.message);
});
